Dataset: Brno_dataset_with_battery_drop_speed_and_label_noise.csv
---------------------------------------------------------------
Source: Semi-synthetic extension of the publicly available Brno LoRaWAN Dataset (Zenodo, 2022)
DOI: https://doi.org/10.5281/zenodo.6467084
Author: Azita Pourghasem et al. (University of Hertfordshire, 2025)
License: Creative Commons Attribution (CC BY 4.0)

Overview:
This dataset was developed to evaluate multi-attribute Physical Layer Authentication (PLA)
against jamming and battery-depletion attacks in LoRaWAN networks. It integrates real LoRaWAN
physical-layer traces (RSSI, SNR, SF) with synthetically modelled energy and altitude attributes
to simulate realistic device behaviour under normal and attack conditions.

Structure:
- device_address: Unique numeric identifier for each node (1–8800)
- event_step: Transmission order per device (1–168)
- rssi: Received Signal Strength Indicator (dBm)
- snr: Signal-to-Noise Ratio (dB)
- sf: Spreading Factor (7–12)
- altitude: Installation height in meters (2–10 m, small drift per device)
- battery_level: Remaining energy percentage
- battery_drop_speed: Change in battery level between consecutive transmissions
- label: 0 = Normal, 1 = Jamming, 2 = Battery-Depletion

Key Statistics:
- Total records: 230,296
- Devices: 1,921
- Duration: 13.68 days
- Class distribution: Normal (90.43%), Jamming (4.83%), Battery-Depletion (4.75%)
- Controlled label noise: ≤ 2%

Usage:
This dataset can be used to benchmark machine-learning models for detecting availability
attacks in LoRaWAN, including jamming and energy-drain behaviour, or to evaluate energy-aware
authentication frameworks.

Citation:
Pourghasem, A., Mylonas, A., Kirner, R., Tsokanos, A., & Mporas, I. (2025).
Multi-Attribute Physical-Layer Authentication Against Jamming and Battery-Depletion Attacks in LoRaWAN.

License:
Creative Commons Attribution (CC BY 4.0)
